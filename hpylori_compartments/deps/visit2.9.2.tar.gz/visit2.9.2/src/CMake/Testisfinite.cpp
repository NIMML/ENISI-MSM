#include <math.h>

int
main(int argc, char *argv[])
{
    int val;
    float f = 1.23456f;
    val = isfinite(f);
    return 0;
}
