#include <stdlib.h>

int
main(int argc, char *arg[])
{
    grantpt(0);
    return 0;
}
