#include <stdlib.h>

int
main(int argc, char *argv[])
{
    char *endptr; float f = strtof("3.5", &endptr);
    return 0;
}
